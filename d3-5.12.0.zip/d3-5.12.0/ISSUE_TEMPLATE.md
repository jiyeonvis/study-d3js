STOP. DO NOT ASK FOR HELP HERE!

If you ignore this message and ask for help anyway, your issue will be closed without a response.

If you want help, please try one of the following forums instead:

Stack Overflow: https://stackoverflow.com/questions/tagged/d3.js  
Slack: https://d3-slackin.herokuapp.com/  
Google Groups: https://groups.google.com/d/forum/d3-js  
Observable: https://observablehq.com/@d3  

ARE YOU REPORTING A BUG, OR MAKING A FEATURE REQUEST? Please file an issue on the relevant D3 module, not here; see https://github.com/d3. Please isolate the specific methods that exhibit unexpected behavior and precisely describe how your expectations were not met.
